const sadPhrases = [
  "La tristeza puede ser un camino hacia el conocimiento de uno mismo.",
  "La tristeza es una mala compañera, pero una buena maestra.",
  "La tristeza es el precio que se paga por ser sensible a la belleza.",
  "Nunca te rindas, incluso si te sientes triste. Siempre hay una razón para seguir adelante."
];

const normalPhrases = [
"La vida es una montaña rusa, con altibajos y momentos de calma.",
"La normalidad no es una meta, es un estado temporal que siempre cambia.",
"Las cosas no siempre son emocionantes, pero eso no las hace menos importantes.",
"No te preocupes si te sientes normal. Es la mayoría de las veces cuando las cosas están bien."
];

const happyPhrases = [
"La felicidad es contagiosa, compártela con los demás.",
"La felicidad es como una mariposa, cuanto más la persigues, más se aleja. Pero si te enfocas en otras cosas, puede venir a ti sin que te des cuenta.",
"La felicidad es el resultado de la suma de pequeñas cosas buenas en la vida.",
"La felicidad no es algo que se encuentra, es algo que se crea."
];

const sadBtn = document.querySelector("#sad-btn");
const normalBtn = document.querySelector("#normal-btn");
const happyBtn = document.querySelector("#happy-btn");
const generateBtn = document.querySelector("#generate-btn");
const phraseOutput = document.querySelector("#phrase-output");

let mood = "";

function selectMood(selectedMood) {
sadBtn.classList.remove("selected");
normalBtn.classList.remove("selected");
happyBtn.classList.remove("selected");
selectedMood.classList.add("selected");

mood = selectedMood.textContent.toLowerCase();
}

function generatePhrase() {
let phrases = [];

switch (mood) {
case "triste":
phrases = sadPhrases;
break;
case "normal":
phrases = normalPhrases;
break;
case "feliz":
phrases = happyPhrases;
break;
}

const randomIndex = Math.floor(Math.random() * phrases.length);
const phrase = phrases[randomIndex];

phraseOutput.textContent = phrase;
}

sadBtn.addEventListener("click", () => selectMood(sadBtn));
normalBtn.addEventListener("click", () => selectMood(normalBtn));
happyBtn.addEventListener("click", () => selectMood(happyBtn));
generateBtn.addEventListener("click", generatePhrase);
