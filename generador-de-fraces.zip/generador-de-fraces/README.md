# generador de fraces 

A Pen created on CodePen.io. Original URL: [https://codepen.io/ignacioicloud01/pen/YzJpvrv](https://codepen.io/ignacioicloud01/pen/YzJpvrv).

